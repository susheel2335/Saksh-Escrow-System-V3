Hi, 
<br /><br />
Your parter have accepted the escrow <?php echo $eid; ?>.

<br /><br />
 

 
 

<br />

With Regards


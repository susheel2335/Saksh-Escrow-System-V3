Hi, 
<br /><br />
You have accepted the escrow <?php echo $eid; ?> successfully.
 <br />
 
<br />

With Regards


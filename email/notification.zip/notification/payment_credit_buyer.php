Hi, <br /><br />

Your deposit has been credited in the escrow <?php echo $eid; ?> and now the seller will ship the product.

<br />
  
<br />

With Regards


Dear <?php echo $seller_name;?>,
<br /><br />
 <?php echo $buyer_email;?> has deposited the required Escrow Amount of <?php echo $deposit_amount;?> FEES CARGO ???
<br /><br />
you can now start shipping the items to the buyer, your funds are secure!
With regards,

<br /><br />
The globalescrow.uk Team